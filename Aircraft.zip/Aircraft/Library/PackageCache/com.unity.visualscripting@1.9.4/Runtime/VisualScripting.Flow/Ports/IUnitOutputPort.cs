namespace Unity.VisualScripting
{
    public interface IUnitOutputPort : IUnitPort { }
}
