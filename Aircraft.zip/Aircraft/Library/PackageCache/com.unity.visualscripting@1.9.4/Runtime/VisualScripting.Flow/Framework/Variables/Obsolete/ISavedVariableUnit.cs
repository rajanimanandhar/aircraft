namespace Unity.VisualScripting
{
    public interface ISavedVariableUnit : IVariableUnit { }
}
