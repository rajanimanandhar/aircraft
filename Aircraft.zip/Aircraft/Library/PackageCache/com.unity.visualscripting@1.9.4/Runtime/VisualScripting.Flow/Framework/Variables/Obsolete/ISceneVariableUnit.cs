namespace Unity.VisualScripting
{
    public interface ISceneVariableUnit : IVariableUnit { }
}
